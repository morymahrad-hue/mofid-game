#!/bin/bash
# ==============================================================================
# اسکریپت راه‌اندازی و اتصال خودکار وب‌هوک ربات بله روی سرور مجازی اختصاصی (VPS)
# دبیرستان مفید یادگار امام - سامانه مفیدگیم (MofidGame 365-Day Engine)
# ==============================================================================

set -e

PORT="${PORT:-20027}"
BALE_TOKEN="${BALE_TOKEN:-1137470430:evmdX1quk7mKJh4Q74TMHinOzi_ZoDplhWM}"
ADMIN_CHAT_ID="${ADMIN_CHAT_ID:-1434129251}"

echo "================================================================="
echo "  🚀 راه‌اندازی وب‌هوک سرور مجازی ربات بله (MofidGame Webhook Engine)"
echo "================================================================="
echo "⚙️ پورت سرور مجازی: $PORT"
echo "🤖 توکن بله: ${BALE_TOKEN:0:10}..."
echo "👑 شناسه مدیر: $ADMIN_CHAT_ID"

# 1. Detect public IP of the VPS
VPS_IP=$(curl -s -4 ifconfig.me || curl -s -4 icanhazip.com || echo "127.0.0.1")
echo "🌐 آی‌پی عمومی سرور مجازی شما: $VPS_IP"

# 2. Check Node.js
if ! command -v node &> /dev/null; then
    echo "📦 در حال نصب Node.js..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs || yum install -y nodejs
fi

echo "✅ نسخه Node.js: $(node -v)"

# 3. Setup Working Directory
WORK_DIR="$HOME/mofidgame-vps-webhook"
mkdir -p "$WORK_DIR"
cd "$WORK_DIR"

# 4. Download / Write vps-webhook-server.cjs
cat << 'EOF' > "$WORK_DIR/vps-webhook-server.cjs"
const http = require('http');
const https = require('https');

const PORT = parseInt(process.env.PORT || '20027', 10);
const BALE_TOKEN = process.env.BALE_TOKEN || '1137470430:evmdX1quk7mKJh4Q74TMHinOzi_ZoDplhWM';
const ADMIN_CHAT_ID = parseInt(process.env.ADMIN_CHAT_ID || '1434129251', 10);

console.log('[MofidGame VPS Webhook] Running on port:', PORT);

function callBaleApi(method, data) {
  return new Promise((resolve, reject) => {
    const postData = JSON.stringify(data || {});
    const req = https.request({
      hostname: 'tapi.bale.ai',
      port: 443,
      path: `/bot${BALE_TOKEN}/${method}`,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(postData),
      },
    }, (res) => {
      let body = '';
      res.on('data', (c) => body += c);
      res.on('end', () => {
        try { resolve(JSON.parse(body)); } catch { resolve({ ok: false, raw: body }); }
      });
    });
    req.on('error', reject);
    req.write(postData);
    req.end();
  });
}

async function sendMessage(chatId, text, replyMarkup) {
  try {
    return await callBaleApi('sendMessage', { chat_id: chatId, text, reply_markup: replyMarkup });
  } catch (err) {
    console.error('[VPS Webhook] Error:', err.message);
  }
}

async function handleUpdate(update) {
  const msg = update.message;
  const cq = update.callback_query;
  if (cq && cq.message && cq.message.chat) {
    await sendMessage(cq.message.chat.id, `✅ گزینه ثبت شد: ${cq.data || ''}`);
    return;
  }
  if (!msg || !msg.chat) return;
  const chatId = msg.chat.id;
  const text = (msg.text || '').trim();

  if (text === '/start') {
    await sendMessage(
      chatId,
      `🎮 به سامانه مفیدگیم (دبیرستان مفید یادگار امام) خوش آمدید!\n\nسرور وب‌هوک شما روی پورت ${PORT} فعال است.`,
      {
        keyboard: [
          [{ text: '🎮 شروع بازی جدید' }, { text: '📚 انتخاب پایه و درس' }],
          [{ text: '🏆 لیگ هفتگی مفید' }, { text: '📊 کارنامه من' }]
        ],
        resize_keyboard: true
      }
    );
  } else if (text === '🎮 شروع بازی جدید') {
    await sendMessage(chatId, '🎯 مسابقه ریاضی پایه هفتم آغاز شد!\nحاصل (-۱۵) + (+۲۳) کدام است؟\n\n۱) +۸\n۲) -۸');
  } else if (text === '🏆 لیگ هفتگی مفید') {
    await sendMessage(chatId, '🏆 برترین‌های لیگ مدرسه مفید:\n۱. پارسا صادقی (نهم ۱) - ۵۲۰ امتیاز 💎\n۲. امیرعلی رضایی (هفتم ۲) - ۴۸۰ امتیاز 🥇');
  } else if (text === '📊 کارنامه من') {
    await sendMessage(chatId, '📊 کارنامه شما:\nدرصد صحت: ۸۸٪\nاستریک روزانه: ۴ روز متوالی 🔥');
  } else {
    await sendMessage(chatId, `پیام دریافت شد: "${text}"\nسامانه وب‌هوک مفیدگیم ۲۴ساعته فعال است.`);
  }
}

const server = http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  if (req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ status: 'online', mode: 'vps_webhook', port: PORT, uptime: process.uptime() }));
  }
  if (req.method === 'POST') {
    let body = '';
    req.on('data', (c) => body += c);
    req.on('end', async () => {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: true }));
      try {
        if (body) await handleUpdate(JSON.parse(body));
      } catch (e) {
        console.error('Update error:', e.message);
      }
    });
    return;
  }
  res.writeHead(404);
  res.end();
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Server listening on port ${PORT}`);
});
EOF

# 5. Start with PM2 or Nohup
if command -v pm2 &> /dev/null; then
    echo "🔄 راه‌اندازی با سرویس دائمی PM2..."
    pm2 stop mofidgame-webhook 2>/dev/null || true
    PORT=$PORT BALE_TOKEN=$BALE_TOKEN ADMIN_CHAT_ID=$ADMIN_CHAT_ID pm2 start "$WORK_DIR/vps-webhook-server.cjs" --name "mofidgame-webhook"
    pm2 save || true
else
    echo "🔄 اجرای دائم با nohup در پس‌زمینه..."
    pkill -f "vps-webhook-server.cjs" 2>/dev/null || true
    PORT=$PORT BALE_TOKEN=$BALE_TOKEN ADMIN_CHAT_ID=$ADMIN_CHAT_ID nohup node "$WORK_DIR/vps-webhook-server.cjs" > "$WORK_DIR/webhook.log" 2>&1 &
fi

# 6. Register Webhook with Bale API
WEBHOOK_URL="http://$VPS_IP:$PORT/api/bale/webhook"
echo "📡 در حال ثبت وب‌هوک در سرور بله به نشانی: $WEBHOOK_URL"

REGISTER_RESP=$(curl -s -X POST "https://tapi.bale.ai/bot$BALE_TOKEN/setWebhook" \
    -H "Content-Type: application/json" \
    -d "{\"url\":\"$WEBHOOK_URL\"}")

echo "📩 پاسخ بله: $REGISTER_RESP"

# 7. Check webhook info
echo "🔍 بررسی اطلاعات وب‌هوک ثبت‌شده:"
curl -s "https://tapi.bale.ai/bot$BALE_TOKEN/getWebhookInfo"

echo ""
echo "================================================================="
echo "✅ وب‌هوک ربات بله با موفقیت روی سرور مجازی شما مستقر و متصل شد!"
echo "🌐 نشانی وب‌هوک: $WEBHOOK_URL"
echo "🟢 هم‌اکنون پیام‌های ارسالی به ربات مستقیماً به سرور مجازی ارسال می‌شود."
echo "================================================================="
