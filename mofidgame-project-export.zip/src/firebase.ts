import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore, doc, getDocFromServer, setDoc, getDocs, collection } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import firebaseConfig from '../firebase-applet-config.json';

const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);

export const firestore = firebaseConfig.firestoreDatabaseId
  ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
  : getFirestore(app);

export const auth = getAuth(app);

export async function testFirestoreConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(firestore, 'test', 'connection'));
    console.log('[Firebase] Connection to Firestore verified.');
    return true;
  } catch (error: any) {
    if (error?.message?.includes('the client is offline')) {
      console.warn('[Firebase] Offline warning during connection test.');
    }
    return true;
  }
}

export async function syncStudentToFirestore(student: any) {
  try {
    await setDoc(doc(firestore, 'students', String(student.id || student.baleChatId)), {
      ...student,
      syncedAt: new Date().toISOString(),
    }, { merge: true });
    return true;
  } catch (err: any) {
    console.error('[Firebase] Failed to sync student:', err.message);
    return false;
  }
}

export async function syncQuestionToFirestore(question: any) {
  try {
    await setDoc(doc(firestore, 'questions', String(question.id)), {
      ...question,
      syncedAt: new Date().toISOString(),
    }, { merge: true });
    return true;
  } catch (err: any) {
    console.error('[Firebase] Failed to sync question:', err.message);
    return false;
  }
}

export async function syncQuizResultToFirestore(result: any) {
  try {
    await setDoc(doc(firestore, 'quizResults', String(result.id)), {
      ...result,
      syncedAt: new Date().toISOString(),
    }, { merge: true });
    return true;
  } catch (err: any) {
    console.error('[Firebase] Failed to sync quiz result:', err.message);
    return false;
  }
}

export default app;
