/**
 * ==============================================================================
 * سرور وب‌هوک اختصاصی ربات بله برای سرور مجازی (VPS Webhook Standalone Server)
 * دبیرستان مفید یادگار امام - سامانه مفیدگیم (MofidGame 365-Day Engine)
 * ==============================================================================
 */

const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');

const PORT = parseInt(process.env.PORT || '20027', 10);
const BALE_TOKEN = process.env.BALE_TOKEN || '1137470430:evmdX1quk7mKJh4Q74TMHinOzi_ZoDplhWM';
const ADMIN_CHAT_ID = parseInt(process.env.ADMIN_CHAT_ID || '1434129251', 10);
const MAIN_APP_URL = process.env.MAIN_APP_URL || 'https://ais-dev-ri2dxsoe6cd3fathvntdgk-126315802530.europe-west3.run.app';

console.log('================================================================');
console.log('🚀 [MofidGame VPS Webhook Server] Starting on port:', PORT);
console.log('🤖 Bot Token:', BALE_TOKEN.substring(0, 10) + '...');
console.log('👑 Admin Chat ID:', ADMIN_CHAT_ID);
console.log('🌐 Central Server Relay:', MAIN_APP_URL);
console.log('================================================================');

// Helper to call Bale API
function callBaleApi(method, data) {
  return new Promise((resolve, reject) => {
    const postData = JSON.stringify(data || {});
    const options = {
      hostname: 'tapi.bale.ai',
      port: 443,
      path: `/bot${BALE_TOKEN}/${method}`,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(postData),
      },
    };

    const req = https.request(options, (res) => {
      let body = '';
      res.on('data', (chunk) => (body += chunk));
      res.on('end', () => {
        try {
          resolve(JSON.parse(body));
        } catch (e) {
          resolve({ ok: false, raw: body });
        }
      });
    });

    req.on('error', reject);
    req.write(postData);
    req.end();
  });
}

// Forward update to main server
function forwardToMainServer(update) {
  return new Promise((resolve, reject) => {
    try {
      const u = new URL(`${MAIN_APP_URL}/api/bale/webhook`);
      const postData = JSON.stringify(update);
      const isHttps = u.protocol === 'https:';
      const client = isHttps ? https : http;

      const req = client.request({
        hostname: u.hostname,
        port: u.port || (isHttps ? 443 : 80),
        path: u.pathname,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(postData),
        },
        timeout: 7000,
      }, (res) => {
        let body = '';
        res.on('data', (c) => body += c);
        res.on('end', () => resolve({ ok: res.statusCode >= 200 && res.statusCode < 300, body }));
      });

      req.on('error', (e) => reject(e));
      req.on('timeout', () => { req.destroy(); reject(new Error('Relay timeout')); });
      req.write(postData);
      req.end();
    } catch (err) {
      reject(err);
    }
  });
}

// Send message helper
async function sendMessage(chatId, text, replyMarkup) {
  try {
    return await callBaleApi('sendMessage', {
      chat_id: chatId,
      text,
      reply_markup: replyMarkup,
    });
  } catch (err) {
    console.error(`[VPS Webhook] Failed to send message to ${chatId}:`, err.message);
  }
}

// Handle incoming update from Bale Webhook
async function handleUpdate(update) {
  // First, relay to central applet with full database and Firebase sync
  try {
    const relayed = await forwardToMainServer(update);
    if (relayed.ok) {
      console.log('[VPS Webhook] Successfully processed via central Cloud engine & Firebase');
      return;
    }
  } catch (relayErr) {
    console.warn('[VPS Webhook] Central engine relay offline, switching to autonomous local responder:', relayErr.message);
  }

  const msg = update.message;
  const cq = update.callback_query;

  if (cq) {
    const chatId = cq.message && cq.message.chat ? cq.message.chat.id : null;
    if (chatId) {
      await sendMessage(chatId, `✅ انتخاب شما ثبت شد: ${cq.data || ''}`);
    }
    return;
  }

  if (!msg || !msg.chat) return;
  const chatId = msg.chat.id;
  const text = (msg.text || '').trim();

  console.log(`[VPS Webhook] Received message from ${chatId}: "${text}"`);

  if (text === '/start') {
    await sendMessage(
      chatId,
      `🎮 **به سامانه بازی‌های آموزشی مفیدگیم (دبیرستان مفید یادگار امام) خوش آمدید!**\n\n` +
      `این ربات به صورت مستقیم از طریق **وب‌هوک سرور مجازی اختصاصی** پاسخگوی شماست و ۲۴ساعته فعال است.\n\n` +
      `برای شروع یکی از گزینه‌های زیر را انتخاب کنید:`,
      {
        keyboard: [
          [{ text: '🎮 شروع بازی جدید' }, { text: '📚 انتخاب پایه و درس' }],
          [{ text: '🏆 لیگ هفتگی مفید' }, { text: '⚔️ دوئل با همکلاسی' }],
          [{ text: '📊 کارنامه و امتیازات' }, { text: '🆘 راهنما و پشتیبانی' }]
        ],
        resize_keyboard: true
      }
    );
  } else if (text === '🎮 شروع بازی جدید' || text === '/play') {
    await sendMessage(
      chatId,
      `🎯 **سؤال آزمایشی پایه هفتم - ریاضی:**\n\nحاصل عبارت (-۱۵) + (+۲۳) کدام است؟\n\n` +
      `۱) +۸\n۲) -۸\n۳) +۳۸\n۴) -۳۸`,
      {
        inline_keyboard: [
          [{ text: '۱) +۸ (درست)', callback_data: 'ans_correct' }, { text: '۲) -۸', callback_data: 'ans_wrong' }],
          [{ text: '۳) +۳۸', callback_data: 'ans_wrong' }, { text: '۴) -۳۸', callback_data: 'ans_wrong' }]
        ]
      }
    );
  } else if (text === '🏆 لیگ هفتگی مفید') {
    await sendMessage(
      chatId,
      `🏆 **جدول برترین‌های لیگ مفیدگیم (پایه‌های هفتم، هشتم، نهم):**\n\n` +
      `🥇 ۱. پارسا صادقی (نهم ۱) - ۵۲۰ امتیاز 💎\n` +
      `🥈 ۲. امیرعلی رضایی (هفتم ۲) - ۴۸۰ امتیاز 🥇\n` +
      `🥉 ۳. محمدرضا حسینی (هشتم ۱) - ۴۱۰ امتیاز 🥈\n\n` +
      `🎖 رتبه شما: در حال محاسبه بر اساس فعالیت هفتگی...`
    );
  } else if (text === '📊 کارنامه من') {
    await sendMessage(chatId, `📊 **کارنامه شما:**\n\nتعداد سؤالات پاسخ‌داده‌شده: ۱۲\nدرصد پاسخ‌های صحیح: ۸۵٪\nاستریک روزانه: ۳ روز پیوسته 🔥`);
  } else if (chatId === ADMIN_CHAT_ID) {
    await sendMessage(chatId, `👑 **پنل مدیریت سرور مجازی وب‌هوک:**\nوضعیت سرور: فعال و آنلاین روی پورت ${PORT}\nزمان فعالیت: ${Math.floor(process.uptime())} ثانیه`);
  } else {
    await sendMessage(chatId, `✅ پیام شما دریافت شد: "${text}"\nاز منوی ربات برای شرکت در مسابقات و آزمون‌ها استفاده کنید.`);
  }
}

// HTTP Server to accept Bale Webhook POST requests
const server = http.createServer(async (req, res) => {
  // CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(200);
    return res.end();
  }

  // Health and ping check
  if (req.method === 'GET' && (req.url === '/' || req.url === '/health' || req.url === '/api/health')) {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({
      status: 'healthy',
      mode: 'vps_webhook_worker',
      port: PORT,
      uptime: process.uptime(),
      timestamp: new Date().toISOString(),
      botOnline: true
    }));
  }

  // Webhook receiver endpoint
  if (req.method === 'POST' && (req.url === '/api/bale/webhook' || req.url === '/webhook' || req.url === '/')) {
    let body = '';
    req.on('data', (chunk) => (body += chunk));
    req.on('end', async () => {
      // Respond 200 OK immediately to Bale
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: true }));

      try {
        if (body) {
          const update = JSON.parse(body);
          await handleUpdate(update);
        }
      } catch (err) {
        console.error('[VPS Webhook] Parse or processing error:', err.message);
      }
    });
    return;
  }

  res.writeHead(404, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ error: 'Not found' }));
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`✅ [VPS Webhook] Listening for Bale updates on http://0.0.0.0:${PORT}/api/bale/webhook`);
});
