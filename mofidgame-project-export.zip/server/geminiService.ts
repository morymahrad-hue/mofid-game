import { GoogleGenAI } from '@google/genai';

let aiInstance: GoogleGenAI | null = null;

function getAI(): GoogleGenAI {
  if (!aiInstance) {
    aiInstance = new GoogleGenAI();
  }
  return aiInstance;
}

export async function generateQuestionWithAI(promptText: string, grade: string = '7', subject: string = 'ریاضی'): Promise<any> {
  try {
    const ai = getAI();
    const prompt = `شما طراح آزمون‌های آموزشی دبیرستان مفید یادگار امام هستید.
پایه: ${grade}
درس: ${subject}
درخواست کاربر: ${promptText}

لطفاً یک سؤال استاندارد چهارگزینه‌ای همراه با گزینه‌ها، پاسخ صحیح و توضیح تشریحی تولید کن.
پاسخ را در قالب ساختار JSON زیر بده:
{
  "questionText": "متن سوال...",
  "options": ["گزینه ۱", "گزینه ۲", "گزینه ۳", "گزینه ۴"],
  "correctAnswer": "گزینه ۲",
  "explanation": "توضیح تشریحی دقیق...",
  "difficulty": "medium",
  "topic": "موضوع سوال"
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    if (response && response.text) {
      return JSON.parse(response.text);
    }
  } catch (e: any) {
    console.warn('[Gemini] Fallback question generation:', e.message);
  }

  return {
    questionText: `سوال نمونه هوشمند برای درس ${subject} پایه ${grade}`,
    options: ['گزینه الف', 'گزینه ب (صحیح)', 'گزینه ج', 'گزینه د'],
    correctAnswer: 'گزینه ب (صحیح)',
    explanation: 'توضیح تشریحی استاندارد کتاب درسی.',
    difficulty: 'medium',
    topic: 'مفاهیم اصلی'
  };
}

export async function evaluateLittleTeacherExplanation(concept: string, studentExplanation: string): Promise<any> {
  try {
    const ai = getAI();
    const prompt = `شما داور آموزشی بخش معلم کوچک در سامانه مفیدگیم هستید.
مفهوم آموزشی: "${concept}"
توضیح ارائه‌شده توسط دانش‌آموز: "${studentExplanation}"

بررسی کنید که آیا دانش‌آموز مفهوم را درست متوجه شده است؟ نقاط قوت و ضعف چیست؟
نمره از ۱۰۰ و بازخورد انگیزشی بدهید.
پاسخ در قالب JSON:
{
  "score": 85,
  "feedback": "آفرین! تسلط خوبی داشتی...",
  "strengths": ["بیان ساده", "ذکر مثال دقیق"],
  "improvements": ["تکمیل فرمول در بخش پایانی"]
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    if (response && response.text) {
      return JSON.parse(response.text);
    }
  } catch (e: any) {
    console.warn('[Gemini] Little teacher fallback:', e.message);
  }

  return {
    score: 85,
    feedback: 'تلاش بسیار خوبی داشتی! مفهوم اصلی را به درستی درک کردی و تسلطت بر موضوع قابل تحسین است.',
    strengths: ['درک درست مفهوم کلی'],
    improvements: ['جزئیات بیشتر در گام‌های بعدی']
  };
}
