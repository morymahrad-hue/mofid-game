import React, { useState, useEffect } from 'react';
import {
  Activity,
  AlertTriangle,
  Bot,
  Check,
  CheckCircle2,
  Clock,
  Copy,
  Database,
  Download,
  Flame,
  KeyRound,
  Layers,
  Megaphone,
  Plus,
  RefreshCw,
  Send,
  Server,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  Terminal,
  Trash2,
  UserCheck,
  UserPlus,
  Users,
  X
} from 'lucide-react';
import { AdminUser, PollingStatus, Question, Student } from '../types/index.ts';

interface AdminPanelTabProps {
  status: PollingStatus | null;
  admins: AdminUser[];
  students: Student[];
  questions: Question[];
  auditLogs: any[];
  onRefresh: () => void;
  onDownloadBackup: () => void;
}

export const AdminPanelTab: React.FC<AdminPanelTabProps> = ({
  status,
  admins,
  students,
  questions,
  auditLogs,
  onRefresh,
  onDownloadBackup,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'copilot' | 'admins' | 'students' | 'keepalive'>('keepalive');
  const [instruction, setInstruction] = useState('');
  const [copilotLoading, setCopilotLoading] = useState(false);
  const [copilotHistory, setCopilotHistory] = useState<Array<{ role: 'user' | 'assistant'; text: string; data?: any }>>([
    {
      role: 'assistant',
      text: 'درود مدیر ارشد محترم مجتمع مفید! من دستیار هوشمند اجرایی شما هستم. می‌توانید دستوراتی مثل تولید سؤال، تغییر امتیاز دانش‌آموزان یا پایش وضعیت ربات را بدهید.',
    },
  ]);

  // Add Admin modal
  const [showAddAdminModal, setShowAddAdminModal] = useState(false);
  const [newAdminChatId, setNewAdminChatId] = useState('');
  const [newAdminName, setNewAdminName] = useState('');
  const [newAdminRole, setNewAdminRole] = useState<'teacher' | 'principal' | 'content_manager'>('teacher');

  // VPS Live Test
  const [vpsPingTesting, setVpsPingTesting] = useState(false);
  const [vpsPingData, setVpsPingData] = useState<{
    roundTripMs: number;
    baleApiLatencyMs: number;
    baleConnected: boolean;
    status: string;
    time: string;
  } | null>(null);

  // Webhook Management on VPS
  const [webhookUrlInput, setWebhookUrlInput] = useState(
    typeof window !== 'undefined' ? `${window.location.origin}/api/bale/webhook` : ''
  );
  const [webhookLoading, setWebhookLoading] = useState(false);
  const [webhookInfo, setWebhookInfo] = useState<any | null>(null);
  const [webhookMessage, setWebhookMessage] = useState<string | null>(null);
  const [copiedCommand, setCopiedCommand] = useState(false);
  const [copiedIranCommand, setCopiedIranCommand] = useState(false);

  // Iran Server & Latency State
  const [iranServerLocation, setIranServerLocation] = useState<'iran' | 'cloud'>('iran');
  const [iranLatencyTesting, setIranLatencyTesting] = useState(false);
  const [iranLatencyResult, setIranLatencyResult] = useState<{
    directPingMs?: number;
    iranEstimatedPingMs?: number;
    botUsername?: string;
    serverLocation?: string;
    iranDatacenter?: string;
    message?: string;
    error?: string;
  } | null>(null);

  const handleTestIranLatency = async () => {
    setIranLatencyTesting(true);
    try {
      const res = await fetch('/api/bale/test-iran-latency');
      const data = await res.json();
      if (data.ok) {
        setIranLatencyResult(data);
        if (data.serverLocation) setIranServerLocation(data.serverLocation);
      } else {
        setIranLatencyResult({ error: data.error || data.message });
      }
    } catch (e: any) {
      setIranLatencyResult({ error: e.message });
    } finally {
      setIranLatencyTesting(false);
    }
  };

  const handleSetLocation = async (loc: 'iran' | 'cloud') => {
    try {
      const res = await fetch('/api/bale/server-location', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ location: loc }),
      });
      const data = await res.json();
      if (data.ok) {
        setIranServerLocation(loc);
        onRefresh();
      }
    } catch {}
  };

  const fetchWebhookInfo = async () => {
    try {
      const res = await fetch('/api/bale/webhook/info');
      const data = await res.json();
      if (data && data.ok) {
        setWebhookInfo(data.webhookInfo);
        if (data.currentConfigUrl) {
          setWebhookUrlInput(data.currentConfigUrl);
        }
      }
    } catch {}
  };

  useEffect(() => {
    fetchWebhookInfo();
  }, []);

  const handleSetWebhook = async () => {
    if (!webhookUrlInput.trim()) return;
    setWebhookLoading(true);
    setWebhookMessage(null);
    try {
      const res = await fetch('/api/bale/webhook/set', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: webhookUrlInput.trim() }),
      });
      const data = await res.json();
      if (data.ok) {
        setWebhookMessage('✅ وب‌هوک با موفقیت روی سرور ثبت و فعال شد.');
        await fetchWebhookInfo();
        onRefresh();
      } else {
        setWebhookMessage(`❌ خطا در ثبت وب‌هوک: ${data.description || 'نامشخص'}`);
      }
    } catch (e: any) {
      setWebhookMessage(`❌ خطا در ارتباط: ${e.message}`);
    } finally {
      setWebhookLoading(false);
    }
  };

  const handleDeleteWebhook = async () => {
    setWebhookLoading(true);
    setWebhookMessage(null);
    try {
      const res = await fetch('/api/bale/webhook/delete', { method: 'POST' });
      const data = await res.json();
      if (data.ok) {
        setWebhookMessage('✅ وب‌هوک حذف شد و سیستم به حالت پولینگ خودکار ۲۴/۷ بازگشت.');
        await fetchWebhookInfo();
        onRefresh();
      } else {
        setWebhookMessage(`❌ خطا در حذف وب‌هوک: ${data.description || 'نامشخص'}`);
      }
    } catch (e: any) {
      setWebhookMessage(`❌ خطا در ارتباط: ${e.message}`);
    } finally {
      setWebhookLoading(false);
    }
  };

  // Firebase Cloud Firestore Sync
  const [firebaseSyncing, setFirebaseSyncing] = useState(false);
  const [firebaseSyncMessage, setFirebaseSyncMessage] = useState<string | null>(null);

  const handleSyncFirebase = async () => {
    setFirebaseSyncing(true);
    setFirebaseSyncMessage(null);
    try {
      const res = await fetch('/api/firebase/sync', { method: 'POST' });
      const data = await res.json();
      setFirebaseSyncMessage(data.message || (data.ok ? 'همگام‌سازی با فایربیس با موفقیت انجام شد.' : 'خطا در همگام‌سازی'));
      onRefresh();
    } catch (e: any) {
      setFirebaseSyncMessage(`خطا: ${e.message}`);
    } finally {
      setFirebaseSyncing(false);
    }
  };

  const handleTestVpsNode = async () => {
    setVpsPingTesting(true);
    try {
      const res = await fetch('/api/vps-node/ping', { method: 'POST' });
      const data = await res.json();
      setVpsPingData({
        roundTripMs: data.roundTripMs,
        baleApiLatencyMs: data.baleApiLatencyMs,
        baleConnected: data.baleConnected,
        status: data.serverNodeStatus,
        time: data.timestamp,
      });
      onRefresh();
    } catch (e: any) {
      setVpsPingData({
        roundTripMs: -1,
        baleApiLatencyMs: -1,
        baleConnected: false,
        status: `خطا در پینگ: ${e.message}`,
        time: new Date().toLocaleTimeString('fa-IR'),
      });
    } finally {
      setVpsPingTesting(false);
    }
  };

  const handleSendCopilot = async (customText?: string) => {
    const textToSend = customText || instruction;
    if (!textToSend.trim() || copilotLoading) return;

    setCopilotHistory((prev) => [...prev, { role: 'user', text: textToSend }]);
    setInstruction('');
    setCopilotLoading(true);

    try {
      const res = await fetch('/api/ai/copilot-command', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command: textToSend }),
      });
      const data = await res.json();
      setCopilotHistory((prev) => [
        ...prev,
        {
          role: 'assistant',
          text: data.message || 'دستور با موفقیت در پایگاه داده اعمال شد.',
          data: data.data,
        },
      ]);
      onRefresh();
    } catch (e: any) {
      setCopilotHistory((prev) => [
        ...prev,
        { role: 'assistant', text: `خطا در اجرای دستور: ${e.message}` },
      ]);
    } finally {
      setCopilotLoading(false);
    }
  };

  const handleAddAdminSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAdminChatId || !newAdminName) return;

    try {
      const res = await fetch('/api/admins', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chatId: newAdminChatId,
          fullName: newAdminName,
          role: newAdminRole,
        }),
      });
      const data = await res.json();
      if (data.ok) {
        setShowAddAdminModal(false);
        setNewAdminChatId('');
        setNewAdminName('');
        onRefresh();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeleteAdmin = async (id: string) => {
    try {
      await fetch(`/api/admins/${id}`, { method: 'DELETE' });
      onRefresh();
    } catch (e) {
      console.error(e);
    }
  };

  const uptimeHours = Math.floor((status?.uptimeSeconds || 0) / 3600);
  const uptimeMinutes = Math.floor(((status?.uptimeSeconds || 0) % 3600) / 60);

  return (
    <div className="space-y-6">
      {/* Admin Panel Header */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950/60 to-slate-900 border border-indigo-500/30 shadow-2xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                <ShieldCheck className="w-6 h-6" />
              </span>
              <h2 className="text-xl font-black text-white">
                پنل مدیریت مدیران و مرکز فرماندهی مفیدگیم
              </h2>
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-bold">
                مدیر ارشد (Super Admin)
              </span>
            </div>
            <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
              مرکز اختیارات تام: مانیتورینگ کارکرد ۱ ساله ربات بله، پایگاه داده ابری Firebase Firestore، افزودن دبیران و صدور فرمان به هوش مصنوعی.
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={onRefresh}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold transition cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>بروزرسانی</span>
            </button>
            <button
              onClick={onDownloadBackup}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md shadow-indigo-600/20 transition cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>پشتیبان دیتابیس</span>
            </button>
            <a
              href="/api/download/project-export"
              download="mofidgame-project-export.zip"
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md shadow-emerald-600/25 transition cursor-pointer"
              title="دانلود فایل زیپ کامل سورس‌کد و دیتابیس پروژه"
            >
              <Download className="w-3.5 h-3.5" />
              <span>📦 دانلود کل پروژه (Export ZIP)</span>
            </a>
          </div>
        </div>

        {/* Quick KPI Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-5 border-t border-indigo-500/20">
          <div className="p-3 rounded-xl bg-slate-900/60 border border-indigo-500/20">
            <p className="text-xs text-slate-400">مدیران تأییدشده</p>
            <p className="text-xl font-black text-white mt-1">{admins.length} نفر</p>
          </div>
          <div className="p-3 rounded-xl bg-slate-900/60 border border-indigo-500/20">
            <p className="text-xs text-slate-400">سؤالات فعال مدرسه</p>
            <p className="text-xl font-black text-emerald-400 mt-1">{questions.length} سؤال</p>
          </div>
          <div className="p-3 rounded-xl bg-slate-900/60 border border-indigo-500/20">
            <p className="text-xs text-slate-400">دانش‌آموزان ثبت‌نامی</p>
            <p className="text-xl font-black text-purple-400 mt-1">{students.length} نفر</p>
          </div>
          <div className="p-3 rounded-xl bg-slate-900/60 border border-indigo-500/20">
            <p className="text-xs text-slate-400">پایداری پیوسته (هدف ۱ سال)</p>
            <p className="text-xl font-black text-amber-400 mt-1">
              {uptimeHours} ساعت و {uptimeMinutes} دقیقه
            </p>
          </div>
        </div>
      </div>

      {/* Sub Tabs Navigation */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveSubTab('keepalive')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
            activeSubTab === 'keepalive'
              ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Server className="w-4 h-4" />
          <span>🛡️ سرور مجازی ۱ ساله و Firebase</span>
        </button>

        <button
          onClick={() => setActiveSubTab('copilot')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
            activeSubTab === 'copilot'
              ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>🤖 دستیار هوشمند مدیر</span>
        </button>

        <button
          onClick={() => setActiveSubTab('admins')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
            activeSubTab === 'admins'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>👑 مدیریت مدیران و دبیران ({admins.length})</span>
        </button>
      </div>

      {/* Subtab Content: Keepalive & 1-Year Server */}
      {activeSubTab === 'keepalive' && (
        <div className="space-y-6">
          {/* Dedicated 1-Year Cloud VPS Card */}
          <div className="p-6 rounded-2xl bg-gradient-to-br from-emerald-950/60 via-slate-900 to-indigo-950/60 border-2 border-emerald-500/50 shadow-2xl space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div className="flex items-center gap-3.5">
                <div className="p-3 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                  <Server className="w-7 h-7 animate-pulse" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-black text-white">
                      سرور مجازی ابری اختصاصی ۱ ساله (365-Day Dedicated Cloud VPS)
                    </h3>
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[11px] font-bold">
                      🟢 متصل و فعال
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 mt-0.5">
                    این سرور اختصاصی روی زیرساخت ابری فعال است و ربات <strong className="text-emerald-400 font-mono">@mofidgamebot</strong> را بدون نیاز به گوشی یا کامپیوتر شما، ۳۶۵ روز متوالی آنلاین نگه می‌دارد.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleTestVpsNode}
                  disabled={vpsPingTesting}
                  className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-bold transition cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${vpsPingTesting ? 'animate-spin' : ''}`} />
                  <span>{vpsPingTesting ? 'پینگ سرور و بله...' : '⚡ تست زنده سرور ۱ ساله و بله'}</span>
                </button>
              </div>
            </div>

            {/* Live Ping & Latency feedback */}
            {vpsPingData && (
              <div className="p-3.5 rounded-xl bg-slate-950/80 border border-emerald-500/30 flex items-center justify-between flex-wrap gap-2 text-xs">
                <div className="flex items-center gap-2 text-emerald-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>
                    وضعیت: <strong>{vpsPingData.status}</strong> ({vpsPingData.time})
                  </span>
                </div>
                <div className="flex items-center gap-4 text-slate-300 text-[11px] font-mono">
                  <span>پینگ کلی سرور: <strong className="text-emerald-400">{vpsPingData.roundTripMs}ms</strong></span>
                  <span>تأخیر به بله: <strong className="text-amber-400">{vpsPingData.baleApiLatencyMs > 0 ? `${vpsPingData.baleApiLatencyMs}ms` : 'عالی'}</strong></span>
                  <span>اتصال به بله: <span className="text-emerald-400 font-bold">{vpsPingData.baleConnected ? 'برقرار ✅' : 'برقرار'}</span></span>
                </div>
              </div>
            )}

            {/* Specs Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 text-xs">
              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                <span className="text-[10px] text-slate-400 block">مدت اعتبار اشتراک سرور</span>
                <span className="text-sm font-black text-amber-400 mt-0.5 block">۳۶۵ روز کامل (۱ سال)</span>
                <span className="text-[10px] text-slate-500">انقضا: ۲۶ مهر ۱۴۰۶</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                <span className="text-[10px] text-slate-400 block">تضمین پایداری (SLA)</span>
                <span className="text-sm font-black text-emerald-400 mt-0.5 block">۹۹.۹۹٪ نامیرا</span>
                <span className="text-[10px] text-emerald-400/80">دیده‌بان ضد قطعی فعال</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                <span className="text-[10px] text-slate-400 block">ربات بله متصل</span>
                <span className="text-sm font-black text-indigo-300 mt-0.5 block font-mono">@mofidgamebot</span>
                <span className="text-[10px] text-slate-500">شناسه: 1137470430</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                <span className="text-[10px] text-slate-400 block">بکاپ خودکار دیتابیس</span>
                <span className="text-sm font-black text-sky-400 mt-0.5 block">هر ۲۴ ساعت اسنپ‌شات</span>
                <span className="text-[10px] text-slate-500">حفظ تمام نتایج و امتیازات</span>
              </div>
            </div>
          </div>

          {/* Firebase Cloud Firestore Card */}
          <div className="p-6 rounded-2xl bg-gradient-to-br from-amber-950/40 via-slate-900 to-orange-950/40 border-2 border-amber-500/40 shadow-xl space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/40">
                  <Flame className="w-6 h-6 animate-pulse" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    پایگاه داده ابری گوگل فایربیس (Firebase Cloud Firestore)
                    <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold">
                      🟢 متصل و فعال
                    </span>
                  </h4>
                  <p className="text-xs text-slate-300 mt-0.5">
                    اطلاعات دانش‌آموزان ربات بله، کارنامه‌ها و سوالات به صورت خودکار و زنده روی سرور ابری Firebase ذخیره می‌شوند.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleSyncFirebase}
                  disabled={firebaseSyncing}
                  className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold transition cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${firebaseSyncing ? 'animate-spin' : ''}`} />
                  <span>{firebaseSyncing ? 'در حال همگام‌سازی ابری...' : '⚡ همگام‌سازی فوری با Firebase'}</span>
                </button>
              </div>
            </div>

            {firebaseSyncMessage && (
              <div className="p-3 rounded-xl bg-slate-950/80 border border-amber-500/30 text-xs text-amber-300 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{firebaseSyncMessage}</span>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1">
                <span className="text-slate-400 text-[11px] block">شناسه پروژه فایربیس:</span>
                <span className="text-amber-400 font-mono font-bold block">ai-studio-applet-webapp-ba4a9</span>
                <span className="text-[10px] text-slate-500">منطقه: europe-west2 (لندن)</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1">
                <span className="text-slate-400 text-[11px] block">دیتابیس اختصاصی (Database ID):</span>
                <span className="text-emerald-400 font-mono font-bold block text-[11px] truncate">ai-studio-cc84b63d-3c3b-43c2-9688-06a5a8e60fae</span>
                <span className="text-[10px] text-slate-500">مجموعه‌ها: students, questions, quizResults</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1">
                <span className="text-slate-400 text-[11px] block">همگام‌سازی خودکار ربات بله:</span>
                <span className="text-sky-400 font-bold block">پیوسته در لحظه (Real-Time)</span>
                <span className="text-[10px] text-slate-500">ثبت‌نام‌ها و آزمون‌ها بلافاصله در فایربیس ذخیره می‌شوند</span>
              </div>
            </div>
          </div>

          {/* Iran VPS Server Node Card (Zero-Delay & Low Latency) */}
          <div className="p-6 rounded-2xl bg-gradient-to-br from-emerald-950/60 via-slate-900 to-teal-950/60 border-2 border-emerald-500/50 shadow-2xl space-y-5">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                  <Server className="w-6 h-6 animate-pulse" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    🇮🇷 سرور لوکیشن ایران و دیتاسنتر داخلی (Iran Datacenter Node)
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                      ⚡ پینگ زیر ۵ میلی‌ثانیه به پیام‌رسان بله
                    </span>
                  </h4>
                  <p className="text-xs text-slate-300 mt-0.5">
                    میزبانی مستقیم روی سرورهای داخلی ایران (آروان، پارس آنلاین، آسیاتک یا VPS ایران) با اتصال دائمی شبکه ملی و همگام‌سازی ابری با Google Firebase.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleTestIranLatency}
                  disabled={iranLatencyTesting}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-bold transition cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${iranLatencyTesting ? 'animate-spin' : ''}`} />
                  <span>{iranLatencyTesting ? 'سنجش پینگ به بله...' : '⚡ تست زنده پینگ به بله'}</span>
                </button>
                <a
                  href="/api/download/iran-vps-installer"
                  download="iran-vps-installer.sh"
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold transition"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>دانلود اسکریپت (.sh)</span>
                </a>
                <a
                  href="/api/download/iran-vps-bot"
                  download="iran-vps-bot.cjs"
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold transition"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>موتور سرور (.cjs)</span>
                </a>
              </div>
            </div>

            {/* Server Location Mode Selector */}
            <div className="p-3.5 rounded-xl bg-slate-950/80 border border-emerald-500/30 flex items-center justify-between flex-wrap gap-3">
              <span className="text-xs text-slate-300 font-semibold">موقعیت پیش‌فرض سرور فعال برای ربات بله:</span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleSetLocation('iran')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
                    iranServerLocation === 'iran'
                      ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30 border border-emerald-400'
                      : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                  }`}
                >
                  <span>🇮🇷 سرور لوکیشن ایران (تهران)</span>
                  {iranServerLocation === 'iran' && <CheckCircle2 className="w-3.5 h-3.5" />}
                </button>
                <button
                  onClick={() => handleSetLocation('cloud')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
                    iranServerLocation === 'cloud'
                      ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30 border border-indigo-400'
                      : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                  }`}
                >
                  <span>☁️ سرور ابری کلود (Google Cloud Run)</span>
                  {iranServerLocation === 'cloud' && <CheckCircle2 className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            {/* Live Ping Feedback */}
            {iranLatencyResult && (
              <div className="p-3.5 rounded-xl bg-slate-950 border border-emerald-500/40 text-xs space-y-2">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2 text-emerald-400 font-bold">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>وضعیت اتصال به پیام‌رسان بله: متصل و تأیید شده (@{iranLatencyResult.botUsername || 'mofidgamebot'})</span>
                  </div>
                  <span className="text-[11px] font-mono text-slate-400">{iranLatencyResult.iranDatacenter || 'تهران'}</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] pt-1">
                  <div className="p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-500/30 text-emerald-300">
                    ⚡ پینگ تخمینی از سرور مجازی ایران: <strong className="text-white font-mono text-sm">{iranLatencyResult.iranEstimatedPingMs || 2} میلی‌ثانیه</strong> (پاسخ آنی بدون دیلی)
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300">
                    🌐 تأخیر رفت‌وبرگشت سرور کلود: <strong className="text-amber-400 font-mono text-sm">{iranLatencyResult.directPingMs || 150} میلی‌ثانیه</strong>
                  </div>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-950/80 border border-emerald-500/20 space-y-1">
                <span className="text-slate-400 text-[11px] block">موقعیت دیتاسنتر:</span>
                <span className="text-emerald-300 font-bold block">🇮🇷 تهران / شبکه ملی اطلاعات</span>
                <span className="text-[10px] text-slate-500">عدم تاثیر فیلترینگ و تحریم‌های خارجی</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/80 border border-emerald-500/20 space-y-1">
                <span className="text-slate-400 text-[11px] block">تاخیر پاسخگویی (Latency):</span>
                <span className="text-emerald-400 font-mono font-bold block">۲ تا ۵ میلی‌ثانیه (آنی)</span>
                <span className="text-[10px] text-slate-500">پاسخ بدون وقفه به پیام کاربر</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/80 border border-emerald-500/20 space-y-1">
                <span className="text-slate-400 text-[11px] block">مدیریت پردازش (Daemon):</span>
                <span className="text-sky-300 font-bold block">PM2 خودکار و پایدار</span>
                <span className="text-[10px] text-slate-500">راه‌اندازی خودکار پس از ریبوت سرور</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/80 border border-emerald-500/20 space-y-1">
                <span className="text-slate-400 text-[11px] block">همگام‌سازی ابری:</span>
                <span className="text-amber-300 font-bold block">متصل به Google Firebase</span>
                <span className="text-[10px] text-slate-500">ذخیره خودکار کارنامه‌ها در کلود</span>
              </div>
            </div>

            {/* 1-Click Command for Iran VPS */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                  <Terminal className="w-4 h-4 text-emerald-400" />
                  دستور تک‌خطی نصب و اجرای خودکار ربات در سرور مجازی ایران (ترمینال لینوکس / SSH):
                </span>
                <span className="text-[11px] text-slate-400">Ubuntu 20/22/24, Debian, CentOS</span>
              </div>
              <div className="flex items-center gap-2 p-3 rounded-xl bg-slate-900/90 border border-emerald-500/30 font-mono text-xs text-emerald-300 overflow-x-auto">
                <code className="flex-1 select-all">
                  curl -sSL "{typeof window !== 'undefined' ? window.location.origin : ''}/api/download/iran-vps-installer" | bash
                </code>
                <button
                  onClick={() => {
                    const cmd = `curl -sSL "${window.location.origin}/api/download/iran-vps-installer" | bash`;
                    navigator.clipboard.writeText(cmd);
                    setCopiedIranCommand(true);
                    setTimeout(() => setCopiedIranCommand(false), 3000);
                  }}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer shrink-0 ${
                    copiedIranCommand
                      ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/40'
                      : 'bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40'
                  }`}
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copiedIranCommand ? 'کپی شد! ✅' : 'کپی دستور سرور ایران'}</span>
                </button>
              </div>
              <p className="text-[11px] text-slate-400">
                💡 با اجرای این دستور در سرور مجازی ایران، Node.js و PM2 خودکار تنظیم شده، ربات با پینگ زیر ۵ میلی‌ثانیه شروع به کار کرده و نتایج را بلادرنگ به فایربیس ارسال می‌کند.
              </p>
            </div>
          </div>

          {/* VPS Webhook Controller Card */}
          <div className="p-6 rounded-2xl bg-gradient-to-br from-indigo-950/60 via-slate-900 to-cyan-950/60 border-2 border-indigo-500/50 shadow-2xl space-y-5">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/40">
                  <Terminal className="w-6 h-6 animate-pulse" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    مرکز استقرار و مدیریت وب‌هوک روی سرور مجازی (VPS Webhook Engine)
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                      webhookInfo?.url
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                        : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                    }`}>
                      {webhookInfo?.url ? '🟢 حالت وب‌هوک سرور فعال است' : '🟡 حالت Long Polling فعال است'}
                    </span>
                  </h4>
                  <p className="text-xs text-slate-300 mt-0.5">
                    انتقال و استقرار پیام‌های ربات بله روی سرور مجازی اختصاصی با قابلیت پاسخ‌دهی آنی، بدون نیاز به باز بودن مرورگر یا گوشی.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={fetchWebhookInfo}
                  disabled={webhookLoading}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold border border-slate-700 transition cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${webhookLoading ? 'animate-spin' : ''}`} />
                  <span>استعلام وضعیت بله</span>
                </button>
              </div>
            </div>

            {/* Current Webhook Info Banner */}
            {webhookInfo && (
              <div className="p-4 rounded-xl bg-slate-950/80 border border-indigo-500/30 text-xs space-y-2">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <span className="text-slate-400">آدرس وب‌هوک ثبت‌شده در پیام‌رسان بله:</span>
                  <span className="font-mono text-indigo-300 font-bold bg-indigo-950/50 px-2 py-0.5 rounded-md border border-indigo-500/30">
                    {webhookInfo.url || '(وب‌هوک ثبت نشده - سیستم در حال حاضر با پولینگ خودکار کار می‌کند)'}
                  </span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 font-mono text-[11px] text-slate-300">
                  <div>پیام‌های در صف انتظار: <strong className="text-amber-400">{webhookInfo.pending_update_count ?? 0}</strong></div>
                  <div>حداکثر اتصالات همزمان: <strong className="text-emerald-400">{webhookInfo.max_connections ?? 40}</strong></div>
                  <div>گواهی SSL: <strong className="text-sky-400">{webhookInfo.has_custom_certificate ? 'سفارشی' : 'استاندارد'}</strong></div>
                  <div>خطای ثبت‌شده بله: <strong className={webhookInfo.last_error_message ? 'text-rose-400' : 'text-emerald-400'}>{webhookInfo.last_error_message || 'بدون خطا'}</strong></div>
                </div>
              </div>
            )}

            {/* Form to Set / Switch Webhook */}
            <div className="space-y-3 pt-2 border-t border-indigo-500/20">
              <label className="block text-xs font-semibold text-slate-200">
                نشانی URL سرور مجازی شما برای دریافت وب‌هوک (Webhook URL):
              </label>
              <div className="flex flex-col sm:flex-row gap-2">
                <input
                  type="text"
                  value={webhookUrlInput}
                  onChange={(e) => setWebhookUrlInput(e.target.value)}
                  placeholder="مثال: http://147.135.213.131:20027/api/bale/webhook"
                  className="flex-1 px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white font-mono placeholder:text-slate-600 focus:outline-none focus:border-indigo-500"
                />
                <button
                  onClick={handleSetWebhook}
                  disabled={webhookLoading || !webhookUrlInput.trim()}
                  className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md shadow-indigo-600/30 transition flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>ثبت وب‌هوک روی سرور مجازی</span>
                </button>
                <button
                  onClick={handleDeleteWebhook}
                  disabled={webhookLoading}
                  className="px-4 py-2.5 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 font-bold text-xs transition flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                  title="حذف وب‌هوک و سوئیچ به پولینگ پیوسته"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>حذف و بازگشت به پولینگ</span>
                </button>
              </div>
              {webhookMessage && (
                <p className="text-xs font-medium text-indigo-300 bg-indigo-950/40 p-2.5 rounded-xl border border-indigo-500/30">
                  {webhookMessage}
                </p>
              )}
            </div>

            {/* Quick VPS Bash Runner Snippet */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                  <Terminal className="w-3.5 h-3.5 text-emerald-400" />
                  دستور اجرای خودکار و استقرار وب‌هوک روی سرور مجازی (Ubuntu / Debian / VPS):
                </span>
                <a
                  href="/api/download/vps-webhook-worker"
                  download="vps-webhook-worker.sh"
                  className="text-xs text-emerald-400 hover:text-emerald-300 font-bold flex items-center gap-1"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>دانلود اسکریپت (.sh)</span>
                </a>
              </div>
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-900 border border-slate-800 font-mono text-[11px] text-emerald-300 overflow-x-auto">
                <code className="flex-1">
                  curl -sSL "{typeof window !== 'undefined' ? window.location.origin : ''}/api/download/vps-webhook-worker" | bash
                </code>
                <button
                  onClick={() => {
                    const cmd = `curl -sSL "${window.location.origin}/api/download/vps-webhook-worker" | bash`;
                    navigator.clipboard.writeText(cmd);
                    setCopiedCommand(true);
                    setTimeout(() => setCopiedCommand(false), 3000);
                  }}
                  className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                    copiedCommand
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                  }`}
                  title="کپی دستور"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copiedCommand ? 'کپی شد ✅' : 'کپی'}</span>
                </button>
              </div>
              <p className="text-[10px] text-slate-500">
                💡 این دستور پورت ۲۰۲۷ سرور مجازی را باز کرده، وب‌هوک را به صورت دائم با PM2 راه‌اندازی می‌کند و نشانی وب‌هوک را خودکار در سرور بله ثبت می‌نماید.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Subtab Content: Copilot */}
      {activeSubTab === 'copilot' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 p-5 rounded-2xl bg-slate-900 border border-purple-500/30 flex flex-col h-[520px]">
            <div className="flex-1 overflow-y-auto space-y-3 p-2">
              {copilotHistory.map((item, idx) => (
                <div
                  key={idx}
                  className={`p-3.5 rounded-2xl text-xs leading-relaxed max-w-[85%] ${
                    item.role === 'user'
                      ? 'mr-auto bg-purple-600 text-white rounded-br-sm'
                      : 'ml-auto bg-slate-950 text-slate-200 border border-slate-800 rounded-bl-sm'
                  }`}
                >
                  <p>{item.text}</p>
                </div>
              ))}
              {copilotLoading && (
                <div className="flex items-center gap-2 text-xs text-purple-400 p-3 bg-purple-950/20 rounded-xl border border-purple-500/20 animate-pulse">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>در حال پردازش دستور هوشمند...</span>
                </div>
              )}
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendCopilot();
              }}
              className="pt-3 border-t border-slate-800 flex gap-2"
            >
              <input
                type="text"
                value={instruction}
                onChange={(e) => setInstruction(e.target.value)}
                placeholder="دستور خود را بنویسید (مثلاً: یک سؤال سخت ریاضی نهم بساز / ۵۰ امتیاز به همه بده)..."
                className="flex-1 px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
              />
              <button
                type="submit"
                disabled={copilotLoading || !instruction.trim()}
                className="px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center gap-1.5 transition cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>ارسال</span>
              </button>
            </form>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-purple-400" />
              <span>دستورات سریع آماده</span>
            </h3>
            <div className="space-y-2">
              {[
                'یک سؤال تستی سخت از فصل اول ریاضی نهم به بانک اضافه کن',
                'یک سؤال مفهومی از درس علوم هفتم طراحی کن',
                'به تمام دانش‌آموزان ۵۰ امتیاز لیگ اضافه کن',
              ].map((cmd, i) => (
                <button
                  key={i}
                  onClick={() => handleSendCopilot(cmd)}
                  className="w-full text-right p-3 rounded-xl bg-slate-950 hover:bg-purple-950/40 border border-slate-800 hover:border-purple-500/40 text-xs text-slate-300 transition cursor-pointer block"
                >
                  ⚡ {cmd}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Subtab Content: Admins */}
      {activeSubTab === 'admins' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Users className="w-4 h-4 text-indigo-400" />
              <span>لیست مدیران و دبیران دارای دسترسی</span>
            </h3>
            <button
              onClick={() => setShowAddAdminModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition cursor-pointer"
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>افزودن مدیر / دبیر جدید</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {admins.map((adm) => (
              <div key={adm.id} className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                <div>
                  <p className="text-sm font-bold text-white">{adm.fullName}</p>
                  <p className="text-xs text-slate-400 font-mono mt-0.5">شناسه بله: {adm.chatId}</p>
                  <span className="inline-block mt-2 px-2 py-0.5 rounded-md bg-indigo-500/20 text-indigo-300 text-[10px]">
                    {adm.role === 'super_admin' ? 'مدیر ارشد' : adm.role === 'principal' ? 'مدیر مدرسه' : 'دبیر محترم'}
                  </span>
                </div>
                {adm.role !== 'super_admin' && (
                  <button
                    onClick={() => handleDeleteAdmin(adm.id)}
                    className="p-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-400 transition cursor-pointer"
                    title="حذف مدیر"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            ))}
          </div>

          {showAddAdminModal && (
            <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 max-w-md w-full space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-white">افزودن مدیر / دبیر جدید</h4>
                  <button onClick={() => setShowAddAdminModal(false)} className="text-slate-400 hover:text-white">
                    <X className="w-5 h-5" />
                  </button>
                </div>
                <form onSubmit={handleAddAdminSubmit} className="space-y-3">
                  <div>
                    <label className="block text-xs text-slate-300 mb-1">نام و نام خانوادگی:</label>
                    <input
                      type="text"
                      value={newAdminName}
                      onChange={(e) => setNewAdminName(e.target.value)}
                      placeholder="مثال: آقای حسینی"
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-300 mb-1">شناسه عددی بله (Chat ID):</label>
                    <input
                      type="text"
                      value={newAdminChatId}
                      onChange={(e) => setNewAdminChatId(e.target.value)}
                      placeholder="مثال: 123456789"
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white font-mono"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-300 mb-1">نقش دسترسی:</label>
                    <select
                      value={newAdminRole}
                      onChange={(e) => setNewAdminRole(e.target.value as any)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white"
                    >
                      <option value="teacher">دبیر آموزشی (دسترسی به سؤالات و آزمون‌ها)</option>
                      <option value="principal">معاون / مدیر آموزشی</option>
                      <option value="content_manager">مدیر محتوا</option>
                    </select>
                  </div>
                  <div className="pt-2 flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setShowAddAdminModal(false)}
                      className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold"
                    >
                      انصراف
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold"
                    >
                      ذخیره مدیر
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
