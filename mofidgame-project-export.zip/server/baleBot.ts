import { db } from './db.ts';
import { GradeLevel, PollingStatus, Question, Student } from '../src/types/index.ts';
import { evaluateLittleTeacherExplanation } from './geminiService.ts';
import { executeAdminAiCommand } from './adminAiCopilot.ts';

interface UserSession {
  state: string;
  tempData?: any;
}

class BaleBotEngine {
  private userSessions: Map<number, UserSession> = new Map();
  private isRunning: boolean = false;
  private abortController: AbortController | null = null;
  private lastUpdateId: number = 0;
  private totalUpdatesProcessed: number = 0;
  private startTime: number = Date.now();
  private lastPollTimestamp: string = '';
  private lastError: string | null = null;
  private botInfo: any = null;
  private processedUpdateIds: Set<number> = new Set();
  private watchdogTimer: NodeJS.Timeout | null = null;
  private watchdogHeartbeatCount: number = 0;
  private autoRecoveryCount: number = 0;
  private keepalivePings: number = 0;
  private lastPollEpoch: number = Date.now();

  constructor() {
    this.startWatchdog();
    this.initBotInfo();
  }

  public async initBotInfo() {
    try {
      const meRes = await this.callBaleApi('getMe');
      if (meRes && meRes.ok) {
        this.botInfo = meRes.result;
        console.log('[Bale Bot] Bot initialized:', meRes.result.username);
      }
    } catch (e: any) {
      console.warn('[Bale Bot] initBotInfo note:', e.message);
    }
  }

  public recordKeepalivePing() {
    this.keepalivePings++;
  }

  public recordWebhookUpdate(update: any) {
    this.keepalivePings++;
    this.totalUpdatesProcessed++;
    if (update && update.update_id) {
      this.lastUpdateId = update.update_id;
    }
    this.lastPollTimestamp = new Date().toLocaleTimeString('fa-IR');
  }

  public getStatus(): PollingStatus {
    const config = db.getConfig();
    const isWebhookMode = !!config.useWebhook;
    return {
      isActive: isWebhookMode ? true : this.isRunning,
      uptimeSeconds: Math.floor((Date.now() - this.startTime) / 1000),
      lastUpdateId: this.lastUpdateId,
      lastPollTimestamp: this.lastPollTimestamp || (isWebhookMode ? 'حالت وب‌هوک فعال است' : 'آماده اتصال'),
      lastError: this.lastError,
      totalUpdatesProcessed: this.totalUpdatesProcessed,
      watchdogHeartbeatCount: this.watchdogHeartbeatCount,
      autoRecoveryCount: this.autoRecoveryCount,
      keepalivePings: this.keepalivePings,
      continuousUptimeDays: Number(((Date.now() - this.startTime) / (1000 * 86400)).toFixed(2)),
      isOneYearModeEnabled: true,
      botInfo: this.botInfo,
    };
  }

  private startWatchdog() {
    if (this.watchdogTimer) clearInterval(this.watchdogTimer);
    this.watchdogTimer = setInterval(() => {
      this.watchdogHeartbeatCount++;
      const config = db.getConfig();
      const now = Date.now();

      // Auto-recover polling whenever bot is not running but token exists
      if (!this.isRunning && config.token) {
        this.autoRecoveryCount++;
        console.log('[Bale Bot Watchdog] Auto-recovering real-time polling...');
        this.startPolling();
      }

      if (this.isRunning && now - this.lastPollEpoch > 40000 && config.token) {
        this.autoRecoveryCount++;
        console.log('[Bale Bot Watchdog] Refreshing long-poll connection...');
        if (this.abortController) {
          try { this.abortController.abort(); } catch {}
        }
        this.isRunning = false;
        setTimeout(() => this.startPolling(), 200);
      }
    }, 3000);
  }

  public async startPolling(): Promise<{ success: boolean; message: string }> {
    const config = db.getConfig();
    if (!config.token) {
      this.lastError = 'توکن ربات بله هنوز تنظیم نشده است.';
      return { success: false, message: 'لطفاً ابتدا توکن ربات بله را وارد کنید.' };
    }

    if (this.isRunning) {
      return { success: true, message: 'سرویس پولینگ در حال حاضر فعال است.' };
    }

    this.isRunning = true;
    this.abortController = new AbortController();
    this.lastError = null;
    db.updateConfig({ isPollingActive: true, useWebhook: false });
    db.addLog('ربات بله', 'شروع پولینگ بلادرنگ', 'سرویس Long Polling بدون وقفه (Zero-Delay) آغاز به کار کرد.');

    // Ensure webhook is removed from Bale so Bale doesn't queue messages for webhook
    try {
      await this.callBaleApi('deleteWebhook');
    } catch {}

    try {
      const meRes = await this.callBaleApi('getMe');
      if (meRes && meRes.ok) {
        this.botInfo = meRes.result;
        console.log('[Bale Bot] Connected to bot:', meRes.result.username);
      }
    } catch (e: any) {
      console.warn('[Bale Bot] getMe note:', e.message);
    }

    this.pollLoop();
    return { success: true, message: 'سرویس پولینگ فوق‌سریع بدون وقفه فعال شد.' };
  }

  public stopPolling() {
    if (this.abortController) {
      this.abortController.abort();
      this.abortController = null;
    }
    this.isRunning = false;
    db.updateConfig({ isPollingActive: false });
    db.addLog('ربات بله', 'توقف پولینگ', 'سرویس Long Polling متوقف شد.');
    return { success: true, message: 'سرویس پولینگ متوقف شد.' };
  }

  private async pollLoop() {
    console.log('[Bale Bot] Ultra-Fast Zero-Delay Polling loop active.');
    while (this.isRunning) {
      const config = db.getConfig();
      if (!config.token) {
        this.isRunning = false;
        break;
      }

      this.lastPollTimestamp = new Date().toLocaleTimeString('fa-IR');
      this.lastPollEpoch = Date.now();
      try {
        const timeoutSeconds = 25;
        const res = await this.callBaleApi('getUpdates', {
          offset: this.lastUpdateId ? this.lastUpdateId + 1 : undefined,
          limit: 50,
          timeout: timeoutSeconds,
        });

        if (res && res.ok && Array.isArray(res.result)) {
          this.lastError = null;
          if (res.result.length > 0) {
            for (const update of res.result) {
              if (this.processedUpdateIds.has(update.update_id)) continue;
              this.processedUpdateIds.add(update.update_id);
              if (this.processedUpdateIds.size > 5000) {
                const firstVal = this.processedUpdateIds.values().next().value;
                if (firstVal !== undefined) this.processedUpdateIds.delete(firstVal);
              }

              this.lastUpdateId = update.update_id;
              this.totalUpdatesProcessed++;

              // Instant asynchronous execution so replies arrive in milliseconds with ZERO delay!
              this.handleIncomingUpdate(update).catch((err: any) => {
                console.error('[Bale Bot] Instant update handling error:', err?.message || err);
              });
            }

            // Zero delay: immediately loop to fetch any newer updates!
            continue;
          }
        } else if (res && !res.ok) {
          this.lastError = `خطای بله: ${res.description || 'نامشخص'}`;
          await new Promise((r) => setTimeout(r, 1000));
        }
      } catch (err: any) {
        if (err.name === 'AbortError') {
          break;
        }
        this.lastError = `خطای شبکه: ${err.message}`;
        await new Promise((r) => setTimeout(r, 1000));
      }

      // Minimal tick so next long-poll starts immediately
      await new Promise((r) => setTimeout(r, 30));
    }
    this.isRunning = false;
  }

  public async callBaleApi(method: string, data?: any): Promise<any> {
    const config = db.getConfig();
    if (!config.token) throw new Error('توکن بله موجود نیست.');

    const url = `https://tapi.bale.ai/bot${config.token}/${method}`;
    const controller = new AbortController();
    const isLongPoll = method === 'getUpdates';
    const timeoutMs = isLongPoll ? 35000 : 10000;
    const timeout = setTimeout(() => controller.abort(), timeoutMs);

    try {
      const resp = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: data ? JSON.stringify(data) : undefined,
        signal: controller.signal,
      });
      clearTimeout(timeout);
      return await resp.json();
    } catch (e: any) {
      clearTimeout(timeout);
      throw e;
    }
  }

  public async sendMessage(chatId: number, text: string, replyMarkup?: any): Promise<any> {
    try {
      const config = db.getConfig();
      if (!config.token) {
        return { ok: true, simulated: true };
      }
      return await this.callBaleApi('sendMessage', {
        chat_id: chatId,
        text,
        reply_markup: replyMarkup,
      });
    } catch (e: any) {
      console.error(`[Bale Bot] SendMessage failed to ${chatId}:`, e.message);
      return null;
    }
  }

  public async simulateUpdate(update: any): Promise<Array<{ text: string; replyMarkup?: any }>> {
    const recordedMessages: Array<{ text: string; replyMarkup?: any }> = [];
    const originalSend = this.sendMessage.bind(this);

    this.sendMessage = async (chatId: number, text: string, replyMarkup?: any) => {
      recordedMessages.push({ text, replyMarkup });
      return { ok: true, result: { message_id: Math.floor(Math.random() * 10000) } };
    };

    try {
      await this.handleIncomingUpdate(update);
    } finally {
      this.sendMessage = originalSend;
    }

    return recordedMessages;
  }

  public async handleIncomingUpdate(update: any) {
    if (update.message) {
      await this.handleMessage(update.message);
    } else if (update.callback_query) {
      await this.handleCallbackQuery(update.callback_query);
    }
  }

  private getMainKeyboard(isAdmin: boolean) {
    const rows = [
      [{ text: '🎮 شروع بازی' }, { text: '📚 انتخاب پایه و درس' }],
      [{ text: '🧠 تمرین هوشمند' }, { text: '📝 آزمون فصل' }],
      [{ text: '🏆 لیگ مفید' }, { text: '⚔️ دوئل با دوستان' }],
      [{ text: '🔁 مرور اشتباهات' }, { text: '📊 کارنامه من' }],
      [{ text: '🎯 مأموریت روزانه' }, { text: '📅 برنامه مطالعه' }],
      [{ text: '💡 آموزش و رفع اشکال' }, { text: '📖 منابع و درسنامه‌ها' }],
      [{ text: '⚙️ تنظیمات' }, { text: '🆘 راهنما و پشتیبانی' }],
    ];
    if (isAdmin) {
      rows.unshift([{ text: '👑 پنل مدیریت' }]);
    }
    return {
      keyboard: rows,
      resize_keyboard: true,
    };
  }

  private async handleMessage(msg: any) {
    const chatId = msg.chat?.id;
    const text = (msg.text || '').trim();
    if (!chatId) return;

    const isAdmin = db.isAdmin(chatId);
    let student = db.getStudentByBaleId(chatId);
    let session = this.userSessions.get(chatId) || { state: 'idle' };

    if (isAdmin && (text === '/admin' || text === '👑 پنل مدیریت' || text === 'بازگشت به پنل مدیریت')) {
      this.userSessions.set(chatId, { state: 'idle' });
      await this.sendAdminMenu(chatId);
      return;
    }

    if (isAdmin && !student && (text === '/start' || session.state === 'idle')) {
      await this.sendMessage(
        chatId,
        `👑 **درود بر مدیر محترم مجتمع مفید یادگار امام!**\n\nشناسه شما به عنوان مدیر تأییدشده شناسایی شد. منوی مدیریت در دسترس شماست:`,
        this.getMainKeyboard(true)
      );
      await this.sendAdminMenu(chatId);
      return;
    }

    if (!student) {
      if (text === '/start' || session.state === 'idle') {
        this.userSessions.set(chatId, { state: 'registering_name', tempData: {} });
        await this.sendMessage(
          chatId,
          `🌱 به **مفیدگیم** خوش آمدید!\n«مدرسه مفید یادگار امام»\n\n🎯 شعار ما: «بازی کن، یاد بگیر، مسلط شو!»\n\nبرای ثبت‌نام، لطفاً **نام و نام‌خانوادگی** خود را ارسال کنید:`
        );
        return;
      }

      if (session.state === 'registering_name') {
        session.tempData.fullName = text;
        session.state = 'registering_grade';
        this.userSessions.set(chatId, session);
        await this.sendMessage(
          chatId,
          `متشکرم ${text} عزیز! 📚 لطفاً پایه تحصیلی خود را انتخاب کنید:`,
          {
            keyboard: [[{ text: 'پایه هفتم' }, { text: 'پایه هشتم' }, { text: 'پایه نهم' }]],
            resize_keyboard: true,
          }
        );
        return;
      }

      if (session.state === 'registering_grade') {
        const gradeMap: any = { 'پایه هفتم': '7', 'پایه هشتم': '8', 'پایه نهم': '9' };
        const g = gradeMap[text] || '7';
        session.tempData.grade = g;
        session.state = 'registering_class';
        this.userSessions.set(chatId, session);
        await this.sendMessage(
          chatId,
          `کلاس خود را مشخص کنید (مثلاً: هفتم ۱، هشتم ۲ یا شهید چمران):`
        );
        return;
      }

      if (session.state === 'registering_class') {
        const newStudent: Student = {
          id: `st_${Date.now()}`,
          baleChatId: chatId,
          username: msg.from?.username || '',
          fullName: session.tempData.fullName,
          grade: session.tempData.grade,
          className: text,
          isApproved: true,
          joinedAt: new Date().toLocaleDateString('fa-IR'),
          lastActiveAt: 'امروز',
          leaguePoints: 100,
          tier: 'برنزی',
          stats: {
            totalAnswered: 0,
            correctAnswers: 0,
            accuracyPercentage: 0,
            streakDays: 1,
            duelsPlayed: 0,
            duelsWon: 0,
          },
        };
        db.saveStudent(newStudent);
        this.userSessions.set(chatId, { state: 'idle' });
        await this.sendMessage(
          chatId,
          `🎉 **ثبت‌نام شما با موفقیت تکمیل شد!**\n\n👤 نام: ${newStudent.fullName}\n📚 پایه: ${newStudent.grade}\n🏫 کلاس: ${newStudent.className}\n🎁 ۱۰۰ امتیاز خوش‌آمدگویی لیگ به شما تعلق گرفت!`,
          this.getMainKeyboard(false)
        );
        return;
      }
    }

    if (text === '🎮 شروع بازی' || text === '🧠 تمرین هوشمند' || text === '📝 آزمون فصل') {
      await this.startPracticeQuiz(chatId, student);
      return;
    }

    if (text === '🏆 لیگ مفید') {
      const students = db.getStudents().sort((a, b) => b.leaguePoints - a.leaguePoints);
      let board = '🏆 **جدول برترین‌های لیگ مفیدگیم**\n\n';
      students.slice(0, 10).forEach((s, idx) => {
        const medal = idx === 0 ? '🥇' : idx === 1 ? '🥈' : idx === 2 ? '🥉' : '🔹';
        board += `${medal} ${idx + 1}. **${s.fullName}** (${s.grade}م) — ${s.leaguePoints} امتیاز\n`;
      });
      if (student) {
        board += `\n⭐️ **رتبه شما:** ${students.findIndex((s) => s.id === student?.id) + 1} با ${student.leaguePoints} امتیاز`;
      }
      await this.sendMessage(chatId, board, this.getMainKeyboard(isAdmin));
      return;
    }

    if (text === '📊 کارنامه من') {
      if (!student) return;
      const card = `📊 **کارنامه تحصیلی مفیدگیم**\n\n👤 نام: ${student.fullName}\n📚 پایه: ${student.grade}\n⭐ امتیاز لیگ: ${student.leaguePoints}\n🎯 درصد دقت کلی: ${student.stats.accuracyPercentage}٪\n🔥 زنجیره مطالعه: ${student.stats.streakDays} روز\n⚔️ دوئل‌های برنده: ${student.stats.duelsWon} از ${student.stats.duelsPlayed}`;
      await this.sendMessage(chatId, card, this.getMainKeyboard(isAdmin));
      return;
    }

    if (session.state === 'in_quiz' && session.tempData) {
      await this.handleQuizAnswer(chatId, text, session);
      return;
    }

    await this.sendMessage(
      chatId,
      `درود بر شما! از منوی زیر یکی از گزینه‌ها را برای یادگیری، مسابقه یا آزمون انتخاب کنید:`,
      this.getMainKeyboard(isAdmin)
    );
  }

  private async startPracticeQuiz(chatId: number, student?: Student) {
    const grade = student?.grade || '7';
    const questions = db.getQuestions({ grade });
    if (questions.length === 0) {
      await this.sendMessage(chatId, 'در حال حاضر سؤالی برای پایه شما در بانک ثبت نشده است.');
      return;
    }

    const q = questions[Math.floor(Math.random() * questions.length)];
    this.userSessions.set(chatId, {
      state: 'in_quiz',
      tempData: {
        questionId: q.id,
        correctAnswer: q.correctAnswer,
        explanation: q.explanation,
        question: q,
      },
    });

    const options = q.options || ['گزینه ۱', 'گزینه ۲', 'گزینه ۳', 'گزینه ۴'];
    const keyboardRows = [
      [{ text: options[0] }, { text: options[1] }],
      [{ text: options[2] }, { text: options[3] }],
      [{ text: '❌ انصراف از آزمون' }],
    ];

    await this.sendMessage(
      chatId,
      `❓ **سؤال تمرینی (${q.topic || 'آزمون'})**\n\n${q.questionText}`,
      { keyboard: keyboardRows, resize_keyboard: true }
    );
  }

  private async handleQuizAnswer(chatId: number, answerText: string, session: UserSession) {
    const isAdmin = db.isAdmin(chatId);
    if (answerText === '❌ انصراف از آزمون') {
      this.userSessions.set(chatId, { state: 'idle' });
      await this.sendMessage(chatId, 'آزمون متوقف شد.', this.getMainKeyboard(isAdmin));
      return;
    }

    const isCorrect = answerText.trim() === session.tempData.correctAnswer.trim();
    const student = db.getStudentByBaleId(chatId);

    if (isCorrect) {
      if (student) {
        db.updateStudent(student.id, {
          leaguePoints: (student.leaguePoints || 0) + 15,
          stats: {
            ...student.stats,
            totalAnswered: (student.stats?.totalAnswered || 0) + 1,
            correctAnswers: (student.stats?.correctAnswers || 0) + 1,
            accuracyPercentage: Math.round((((student.stats?.correctAnswers || 0) + 1) / ((student.stats?.totalAnswered || 0) + 1)) * 100),
          },
        });
      }
      this.userSessions.set(chatId, { state: 'idle' });
      await this.sendMessage(
        chatId,
        `✅ **آفرین! پاسخ شما کاملاً درست بود.**\n➕ ۱۵ امتیاز لیگ دریافت کردید!\n\n💡 **پاسخ تشریحی:**\n${session.tempData.explanation}`,
        this.getMainKeyboard(isAdmin)
      );
    } else {
      if (student) {
        db.updateStudent(student.id, {
          stats: {
            ...student.stats,
            totalAnswered: (student.stats?.totalAnswered || 0) + 1,
            accuracyPercentage: Math.round(((student.stats?.correctAnswers || 0) / ((student.stats?.totalAnswered || 0) + 1)) * 100),
          },
        });
      }
      this.userSessions.set(chatId, { state: 'idle' });
      await this.sendMessage(
        chatId,
        `❌ **متأسفانه پاسخ نادرست بود.**\nپاسخ صحیح: **${session.tempData.correctAnswer}**\n\n💡 **پاسخ تشریحی:**\n${session.tempData.explanation}`,
        this.getMainKeyboard(isAdmin)
      );
    }
  }

  private async sendAdminMenu(chatId: number) {
    const text = `👑 **پنل مدیریت مجتمع آموزشی مفید**\n\nآمار زنده:\n👥 دانش‌آموزان: ${db.getStudents().length} نفر\n❓ سؤالات فعال: ${db.getQuestions().length} سؤال\n🟢 وضعیت سیستم: ۲۴ ساعته آنلاین و همگام با Firebase`;
    await this.sendMessage(chatId, text, this.getMainKeyboard(true));
  }

  private async handleCallbackQuery(cq: any) {
    // Acknowledge callback
  }
}

export const baleBot = new BaleBotEngine();
