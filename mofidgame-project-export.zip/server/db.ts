import fs from 'fs';
import path from 'path';
import {
  saveStudentToFirebase,
  saveQuestionToFirebase,
  saveQuizResultToFirebase,
  initFirebaseBackend
} from './firebaseSync.ts';
import {
  AdminUser,
  BaleConfig,
  Chapter,
  LeitnerItem,
  OfficialResource,
  Question,
  QuizResult,
  Student,
  Subject
} from '../src/types/index.ts';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'mofidgame_db.json');
const BACKUP_DIR = path.join(DATA_DIR, 'backups');

export interface DatabaseSchema {
  config: BaleConfig;
  admins: AdminUser[];
  subjects: Subject[];
  chapters: Chapter[];
  questions: Question[];
  students: Student[];
  leitnerItems: LeitnerItem[];
  quizResults: QuizResult[];
  resources: OfficialResource[];
  auditLogs: {
    id: string;
    timestamp: string;
    actor: string;
    action: string;
    details: string;
  }[];
}

const defaultSubjects: Subject[] = [
  { id: 'math_7', name: 'ریاضی هفتم', icon: '📐', grade: '7', chaptersCount: 9, description: 'اعداد صحیح، هندسه، جبر و معادله، توان، آمار و احتمال' },
  { id: 'science_7', name: 'علوم تجربی هفتم', icon: '🔬', grade: '7', chaptersCount: 15, description: 'ماده و تغییرات، اتم‌ها، زیست‌شناسی، فیزیک حرکت و انرژی' },
  { id: 'persian_7', name: 'ادبیات فارسی هفتم', icon: '📖', grade: '7', chaptersCount: 6, description: 'دستور زبان، آرایه‌های ادبی، درک مطلب، نگارش' },
  { id: 'english_7', name: 'زبان انگلیسی هفتم', icon: '🌍', grade: '7', chaptersCount: 8, description: 'مکالمه، واژگان روزمره و درک شنیداری' },

  { id: 'math_8', name: 'ریاضی هشتم', icon: '📐', grade: '8', chaptersCount: 9, description: 'عددهای گویا، حساب اعداد طبیعی، چندضلعی‌ها، بردار، توان و جذر' },
  { id: 'science_8', name: 'علوم تجربی هشتم', icon: '🔬', grade: '8', chaptersCount: 15, description: 'تغییرات شیمیایی، تنظیم عصبی، حس و حرکت، الکتریسیته' },
  { id: 'persian_8', name: 'ادبیات فارسی هشتم', icon: '📖', grade: '8', chaptersCount: 6, description: 'نقش‌های دستوری، جناس، تشبیه، استعاره' },

  { id: 'math_9', name: 'ریاضی نهم', icon: '📐', grade: '9', chaptersCount: 8, description: 'مجموعه‌ها، عددهای حقیقی، استدلال و اثبات در هندسه، خط' },
  { id: 'science_9', name: 'علوم تجربی نهم', icon: '🔬', grade: '9', chaptersCount: 15, description: 'مواد و نقش آنها، ماشین‌ها، فشار و آثار آن، زمین‌ساخت ورقی' },
  { id: 'persian_9', name: 'ادبیات فارسی نهم', icon: '📖', grade: '9', chaptersCount: 6, description: 'وزن شعر، قرابت معنایی، آرایه‌های ترکیبی' }
];

const defaultChapters: Chapter[] = [
  { id: 'm7_ch1', subjectId: 'math_7', grade: '7', number: 1, title: 'راهبردهای حل مسئله', learningObjectives: ['رسم شکل', 'الگوسازی', 'حذف حالت‌های نامطلوب'], prerequisites: ['ریاضی ششم'] },
  { id: 'm7_ch2', subjectId: 'math_7', grade: '7', number: 2, title: 'عددهای صحیح', learningObjectives: ['محور اعداد صحیح', 'جمع و تفریق عدد صحیح'], prerequisites: ['اعداد منفی پایه'] },
  { id: 'm7_ch3', subjectId: 'math_7', grade: '7', number: 3, title: 'جبر و معادله', learningObjectives: ['الگوهای عددی', 'عبارت‌های جبری', 'معادله'], prerequisites: ['عددهای صحیح'] },
  { id: 's7_ch1', subjectId: 'science_7', grade: '7', number: 1, title: 'تجربه و تفکر', learningObjectives: ['روش علمی', 'اندازه‌گیری و ابزارها'], prerequisites: ['علوم ششم'] },
  { id: 'm8_ch1', subjectId: 'math_8', grade: '8', number: 1, title: 'عددهای صحیح و گویا', learningObjectives: ['یادآوری عددهای صحیح', 'معرفی عددهای گویا'], prerequisites: ['ریاضی هفتم'] },
  { id: 's8_ch1', subjectId: 'science_8', grade: '8', number: 1, title: 'مخلوط و جداسازی مواد', learningObjectives: ['مخلوط‌های همگن و ناهمگن'], prerequisites: ['علوم هفتم'] },
  { id: 'm9_ch1', subjectId: 'math_9', grade: '9', number: 1, title: 'مجموعه‌ها', learningObjectives: ['معرفی مجموعه', 'مجموعه‌های برابر و زیرمجموعه', 'تفاضل و اشتراک'], prerequisites: ['ریاضی هشتم'] },
  { id: 's9_ch1', subjectId: 'science_9', grade: '9', number: 1, title: 'مواد و نقش آنها در زندگی', learningObjectives: ['عناصر نافلز و فلز', 'بسپارها'], prerequisites: ['علوم هشتم'] }
];

const defaultQuestions: Question[] = [
  {
    id: 'q_m7_01',
    grade: '7',
    subjectId: 'math_7',
    chapterId: 'm7_ch2',
    topic: 'جمع و تفریق اعداد صحیح',
    type: 'four_choice',
    difficulty: 'easy',
    questionText: 'حاصل عبارت (-۱۵) + (+۲۳) - (-۷) کدام است؟',
    options: ['+۱۵', '+۲۵', '+۳۱', '+۱'],
    correctAnswer: '+۱۵',
    explanation: 'ابتدا منفی در منفی مثبت می‌شود: (-۱۵) + ۲۳ + ۷ = ۸ + ۷ = ۱۵.',
    status: 'approved',
    source: 'کتاب ریاضی هفتم، فصل ۲',
    createdAt: new Date().toISOString()
  },
  {
    id: 'q_m7_02',
    grade: '7',
    subjectId: 'math_7',
    chapterId: 'm7_ch3',
    topic: 'معادله جبری',
    type: 'four_choice',
    difficulty: 'medium',
    questionText: 'در معادله ۳x - ۵ = ۱۰، مقدار x کدام است؟',
    options: ['۳', '۵', '۴', '۶'],
    correctAnswer: '۵',
    explanation: '۳x = ۱۰ + ۵ => ۳x = ۱۵ => x = ۵.',
    status: 'approved',
    source: 'کتاب ریاضی هفتم، فصل ۳',
    createdAt: new Date().toISOString()
  },
  {
    id: 'q_s7_01',
    grade: '7',
    subjectId: 'science_7',
    chapterId: 's7_ch1',
    topic: 'اندازه‌گیری در علوم',
    type: 'four_choice',
    difficulty: 'easy',
    questionText: 'یکای استاندارد بین‌المللی (SI) برای اندازه‌گیری جرم کدام است؟',
    options: ['گرم', 'کیلوگرم', 'نیوتون', 'تن'],
    correctAnswer: 'کیلوگرم',
    explanation: 'یکای استاندارد جرم در سیستم SI کیلوگرم (kg) است.',
    status: 'approved',
    source: 'کتاب علوم هفتم، فصل ۱',
    createdAt: new Date().toISOString()
  },
  {
    id: 'q_m8_01',
    grade: '8',
    subjectId: 'math_8',
    chapterId: 'm8_ch1',
    topic: 'عددهای گویا',
    type: 'four_choice',
    difficulty: 'medium',
    questionText: 'معکوس قرینه کسر -۳/۵ کدام است؟',
    options: ['+۵/۳', '-۵/۳', '+۳/۵', '-۳/۵'],
    correctAnswer: '+۵/۳',
    explanation: 'قرینه -۳/۵ برابر +۳/۵ است و معکوس آن +۵/۳ است.',
    status: 'approved',
    source: 'کتاب ریاضی هشتم، فصل ۱',
    createdAt: new Date().toISOString()
  },
  {
    id: 'q_m9_01',
    grade: '9',
    subjectId: 'math_9',
    chapterId: 'm9_ch1',
    topic: 'مجموعه‌ها',
    type: 'four_choice',
    difficulty: 'medium',
    questionText: 'اگر A = {۱, ۲, ۳, ۴} و B = {۳, ۴, ۵, ۶} باشد، حاصل A - B کدام است؟',
    options: ['{۱, ۲}', '{۵, ۶}', '{۳, ۴}', '{۱, ۲, ۵, ۶}'],
    correctAnswer: '{۱, ۲}',
    explanation: 'اعضایی که در A هستند ولی در B نیستند: {۱, ۲}.',
    status: 'approved',
    source: 'کتاب ریاضی نهم، فصل ۱',
    createdAt: new Date().toISOString()
  }
];

const defaultStudents: Student[] = [
  {
    id: 'st_01',
    baleChatId: 1000001,
    username: 'ali_mofidi',
    fullName: 'علی رضایی',
    grade: '7',
    className: 'هفتم ۱ (شهید چمران)',
    isApproved: true,
    joinedAt: '۱۴۰۵/۰۷/۰۱',
    lastActiveAt: 'امروز',
    leaguePoints: 340,
    tier: 'طلایی',
    stats: { totalAnswered: 45, correctAnswers: 41, accuracyPercentage: 91, streakDays: 8, duelsPlayed: 6, duelsWon: 5 }
  },
  {
    id: 'st_02',
    baleChatId: 1000002,
    username: 'mohammad_m',
    fullName: 'محمد مهدوی',
    grade: '8',
    className: 'هشتم ۲ (شهید بهشتی)',
    isApproved: true,
    joinedAt: '۱۴۰۵/۰۷/۰۲',
    lastActiveAt: 'امروز',
    leaguePoints: 290,
    tier: 'نقره‌ای',
    stats: { totalAnswered: 38, correctAnswers: 32, accuracyPercentage: 84, streakDays: 5, duelsPlayed: 4, duelsWon: 3 }
  },
  {
    id: 'st_03',
    baleChatId: 1000003,
    username: 'hossein_k',
    fullName: 'حسین کاظمی',
    grade: '9',
    className: 'نهم ۱ (شهید مطهری)',
    isApproved: true,
    joinedAt: '۱۴۰۵/۰۷/۰۳',
    lastActiveAt: 'دیروز',
    leaguePoints: 410,
    tier: 'الماس',
    stats: { totalAnswered: 52, correctAnswers: 48, accuracyPercentage: 92, streakDays: 12, duelsPlayed: 9, duelsWon: 8 }
  }
];

const defaultAdmins: AdminUser[] = [
  {
    id: 'adm_01',
    chatId: 1434129251,
    fullName: 'مدیر ارشد مجتمع مفید',
    role: 'super_admin',
    addedAt: '۱۴۰۵/۰۱/۰۱',
    permissions: {
      canManageQuestions: true,
      canManageStudents: true,
      canBroadcast: true,
      canUseAiCopilot: true,
      canManageAdmins: true
    }
  }
];

const defaultResources: OfficialResource[] = [
  {
    id: 'res_m7',
    title: 'کتاب درسی ریاضی پایه هفتم (چاپ ۱۴۰۵)',
    grade: '7',
    subjectId: 'math_7',
    type: 'textbook_pdf',
    officialSource: 'chap.sch.ir',
    downloadUrl: 'https://chap.sch.ir',
    description: 'کتاب رسمی وزارت آموزش و پرورش',
    status: 'synced',
    lastCheckedDate: '۱۴۰۵/۰۷/۱۵'
  },
  {
    id: 'res_m8',
    title: 'کتاب درسی ریاضی پایه هشتم (چاپ ۱۴۰۵)',
    grade: '8',
    subjectId: 'math_8',
    type: 'textbook_pdf',
    officialSource: 'chap.sch.ir',
    downloadUrl: 'https://chap.sch.ir',
    description: 'کتاب رسمی وزارت آموزش و پرورش',
    status: 'synced',
    lastCheckedDate: '۱۴۰۵/۰۷/۱۵'
  },
  {
    id: 'res_m9',
    title: 'کتاب درسی ریاضی پایه نهم (چاپ ۱۴۰۵)',
    grade: '9',
    subjectId: 'math_9',
    type: 'textbook_pdf',
    officialSource: 'chap.sch.ir',
    downloadUrl: 'https://chap.sch.ir',
    description: 'کتاب رسمی وزارت آموزش و پرورش',
    status: 'synced',
    lastCheckedDate: '۱۴۰۵/۰۷/۱۵'
  }
];

class Database {
  private data: DatabaseSchema;

  constructor() {
    this.ensureDirs();
    this.data = this.load();
    try {
      initFirebaseBackend();
    } catch (e: any) {
      console.warn('[DB] Firebase initialization note:', e?.message || e);
    }
  }

  private ensureDirs() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(BACKUP_DIR)) {
      fs.mkdirSync(BACKUP_DIR, { recursive: true });
    }
  }

  private load(): DatabaseSchema {
    try {
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        if (!parsed.admins || parsed.admins.length === 0) {
          parsed.admins = defaultAdmins;
        }
        return parsed;
      }
    } catch (e) {
      console.error('[DB] Load error, resetting defaults:', e);
    }

    const initial: DatabaseSchema = {
      config: {
        token: process.env.BALE_BOT_TOKEN || '1137470430:evmdX1quk7mKJh4Q74TMHinOzi_ZoDplhWM',
        botUsername: 'mofidgamebot',
        adminChatId: parseInt(process.env.BALE_ADMIN_CHAT_ID || '1434129251', 10),
        adminChatIds: [1434129251],
        isPollingActive: true,
        useWebhook: false,
        webhookUrl: '',
        schoolInviteCode: 'MOFID-1405',
        pollingIntervalMs: 1500
      },
      admins: defaultAdmins,
      subjects: defaultSubjects,
      chapters: defaultChapters,
      questions: defaultQuestions,
      students: defaultStudents,
      leitnerItems: [],
      quizResults: [],
      resources: defaultResources,
      auditLogs: [
        {
          id: 'log_01',
          timestamp: new Date().toISOString(),
          actor: 'سیستم',
          action: 'راه‌اندازی اولیه',
          details: 'پایگاه داده سامانه مفیدگیم برای پایه‌های هفتم، هشتم و نهم مقداردهی شد.'
        }
      ]
    };

    this.saveDirect(initial);
    return initial;
  }

  private saveDirect(data: DatabaseSchema) {
    try {
      this.ensureDirs();
      fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
    } catch (e) {
      console.error('[DB] Failed to save database:', e);
    }
  }

  public save() {
    this.saveDirect(this.data);
  }

  public backup(): string {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = `backup_${timestamp}.json`;
    const target = path.join(BACKUP_DIR, filename);
    fs.writeFileSync(target, JSON.stringify(this.data, null, 2), 'utf-8');
    this.addLog('مدیر سامانه', 'پشتیبان‌گیری', `فایل پشتیبان ${filename} ایجاد شد.`);
    return filename;
  }

  public restore(backupJson: string): boolean {
    try {
      const parsed = JSON.parse(backupJson);
      if (parsed.subjects && parsed.questions && parsed.students) {
        this.data = parsed;
        this.save();
        this.addLog('مدیر سامانه', 'بازیابی پایگاه داده', 'داده‌ها با موفقیت از فایل پشتیبان بازگردانده شدند.');
        return true;
      }
      return false;
    } catch (e) {
      console.error('[DB] Restore error:', e);
      return false;
    }
  }

  public addLog(actor: string, action: string, details: string) {
    const log = {
      id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toISOString(),
      actor,
      action,
      details
    };
    this.data.auditLogs.unshift(log);
    if (this.data.auditLogs.length > 500) {
      this.data.auditLogs.pop();
    }
    this.save();
  }

  public getConfig(): BaleConfig {
    return this.data.config;
  }

  public updateConfig(patch: Partial<BaleConfig>) {
    this.data.config = { ...this.data.config, ...patch };
    this.save();
  }

  public getStudents(): Student[] {
    return this.data.students;
  }

  public getStudentByBaleId(chatId: number): Student | undefined {
    return this.data.students.find((s) => s.baleChatId === chatId);
  }

  public saveStudent(student: Student) {
    const index = this.data.students.findIndex((s) => s.id === student.id || s.baleChatId === student.baleChatId);
    if (index >= 0) {
      this.data.students[index] = student;
    } else {
      this.data.students.push(student);
    }
    this.save();
    try {
      saveStudentToFirebase(student).catch(() => {});
    } catch {}
  }

  public getAdmins(): AdminUser[] {
    return this.data.admins || defaultAdmins;
  }

  public addAdmin(admin: AdminUser): AdminUser {
    if (!this.data.admins) this.data.admins = [...defaultAdmins];
    const exists = this.data.admins.find((a) => a.chatId === admin.chatId || a.id === admin.id);
    if (!exists) {
      this.data.admins.push(admin);
    }
    if (!this.data.config.adminChatIds) this.data.config.adminChatIds = [this.data.config.adminChatId];
    if (!this.data.config.adminChatIds.includes(admin.chatId)) {
      this.data.config.adminChatIds.push(admin.chatId);
    }
    this.save();
    return admin;
  }

  public deleteAdmin(idOrChatId: string | number): boolean {
    if (!this.data.admins) return false;
    const initialLen = this.data.admins.length;
    this.data.admins = this.data.admins.filter((a) => a.id !== idOrChatId && a.chatId !== Number(idOrChatId));
    if (this.data.config.adminChatIds) {
      this.data.config.adminChatIds = this.data.config.adminChatIds.filter((cid) => cid !== Number(idOrChatId));
    }
    if (this.data.admins.length !== initialLen) {
      this.save();
      return true;
    }
    return false;
  }

  public isAdmin(chatId: number): boolean {
    if (chatId === this.data.config.adminChatId) return true;
    if (this.data.config.adminChatIds && this.data.config.adminChatIds.includes(chatId)) return true;
    if (this.data.admins && this.data.admins.some((a) => a.chatId === chatId)) return true;
    return false;
  }

  public getAdminByChatId(chatId: number): AdminUser | undefined {
    return this.data.admins?.find((a) => a.chatId === chatId);
  }

  public deleteStudent(id: string): boolean {
    const initialLen = this.data.students.length;
    this.data.students = this.data.students.filter((s) => s.id !== id && s.baleChatId !== Number(id));
    if (this.data.students.length !== initialLen) {
      this.save();
      return true;
    }
    return false;
  }

  public updateStudent(id: string, patch: Partial<Student>): Student | null {
    const index = this.data.students.findIndex((s) => s.id === id || s.baleChatId === Number(id));
    if (index === -1) return null;
    this.data.students[index] = { ...this.data.students[index], ...patch };
    this.save();
    try {
      saveStudentToFirebase(this.data.students[index]).catch(() => {});
    } catch {}
    return this.data.students[index];
  }

  public getSubjects(grade?: string): Subject[] {
    if (!grade) return this.data.subjects;
    return this.data.subjects.filter((s) => s.grade === grade);
  }

  public getChapters(subjectId?: string): Chapter[] {
    if (!subjectId) return this.data.chapters;
    return this.data.chapters.filter((c) => c.subjectId === subjectId);
  }

  public getQuestions(filters?: { grade?: string; subjectId?: string; difficulty?: string; status?: string }): Question[] {
    return this.data.questions.filter((q) => {
      if (filters?.grade && q.grade !== filters.grade) return false;
      if (filters?.subjectId && q.subjectId !== filters.subjectId) return false;
      if (filters?.difficulty && q.difficulty !== filters.difficulty) return false;
      if (filters?.status && q.status !== filters.status) return false;
      return true;
    });
  }

  public getQuestionById(id: string): Question | undefined {
    return this.data.questions.find((q) => q.id === id);
  }

  public addQuestion(question: Question): Question {
    this.data.questions.unshift(question);
    this.save();
    try {
      saveQuestionToFirebase(question).catch(() => {});
    } catch {}
    return question;
  }

  public updateQuestion(id: string, patch: Partial<Question>): Question | null {
    const index = this.data.questions.findIndex((q) => q.id === id);
    if (index === -1) return null;
    this.data.questions[index] = { ...this.data.questions[index], ...patch };
    this.save();
    try {
      saveQuestionToFirebase(this.data.questions[index]).catch(() => {});
    } catch {}
    return this.data.questions[index];
  }

  public deleteQuestion(id: string): boolean {
    const initialLen = this.data.questions.length;
    this.data.questions = this.data.questions.filter((q) => q.id !== id);
    if (this.data.questions.length !== initialLen) {
      this.save();
      return true;
    }
    return false;
  }

  public getResources(): OfficialResource[] {
    return this.data.resources;
  }

  public addResource(resource: OfficialResource): OfficialResource {
    this.data.resources.push(resource);
    this.save();
    return resource;
  }

  public updateResourceStatus(id: string, status: any): boolean {
    const res = this.data.resources.find((r) => r.id === id);
    if (res) {
      res.status = status;
      res.lastCheckedDate = new Date().toLocaleDateString('fa-IR');
      this.save();
      return true;
    }
    return false;
  }

  public getLeitnerItems(studentId: string): LeitnerItem[] {
    return this.data.leitnerItems.filter((i) => i.studentId === studentId);
  }

  public saveLeitnerItem(item: LeitnerItem) {
    const idx = this.data.leitnerItems.findIndex((i) => i.id === item.id || (i.studentId === item.studentId && i.questionId === item.questionId));
    if (idx >= 0) {
      this.data.leitnerItems[idx] = item;
    } else {
      this.data.leitnerItems.push(item);
    }
    this.save();
  }

  public addQuizResult(res: QuizResult) {
    this.data.quizResults.unshift(res);
    this.save();
    try {
      saveQuizResultToFirebase(res).catch(() => {});
    } catch {}
  }

  public getQuizResults(studentId?: string): QuizResult[] {
    if (!studentId) return this.data.quizResults;
    return this.data.quizResults.filter((r) => r.studentId === studentId);
  }

  public getAuditLogs() {
    return this.data.auditLogs;
  }

  public getRawData(): DatabaseSchema {
    return this.data;
  }
}

export const db = new Database();
